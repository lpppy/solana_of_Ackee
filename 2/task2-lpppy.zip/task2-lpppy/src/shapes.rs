///-------------------------------------------------------------------------------
///
/// This is your first task to get warmed up and see how useful traits can be.
/// 
/// Complete the implementation of methods in the Rectangle and Circle structs, 
/// then implement the Shape trait for both structs.
/// 
/// Tasks:
/// 1. Implement Rectangle struct methods (constructor, setters, getters)
/// 2. Implement Circle struct methods (constructor, setter, getter)  
/// 3. Implement the Shape trait for both Rectangle and Circle
/// 4. Handle validation errors properly using the Error enum
/// 
///-------------------------------------------------------------------------------
use std::f64::consts::PI;

pub trait Shape {
    fn area(&self) -> f64;
    fn perimeter(&self) -> f64;
}

pub struct Rectangle {
    width: f64,
    height: f64,
}

pub struct Circle {
    radius: f64,
}

#[derive(Debug, PartialEq)]
pub enum Error {
    InvalidWidth,
    InvalidHeight,
    InvalidRadius,
}

// TODO: Implement constructor with setters and getters.
// 
// Width and height are considered invalid if they are negative. 
// All methods should return the corresponding error when invalid values are provided.
impl Rectangle {
    pub fn new(width: f64, height: f64) -> Result<Self, Error> {
        if width < 0.0 {
            Err(Error::InvalidWidth)
        } else if height < 0.0 {
            Err(Error::InvalidHeight)
        } else {
            Ok(Self { width: width, height: height })
        }
    }

    pub fn set_width(&mut self, width: f64) -> Result<(), Error> {
        match width {
            n if n < 0.0 => Err(Error::InvalidWidth),
            _ => Ok(self.width = width)
        }
    }
    pub fn set_height(&mut self, height: f64) -> Result<(), Error> {
        match height {
            n if n < 0.0 => Err(Error::InvalidHeight),
            _ => Ok(self.height = height)
        }
    }
    pub fn get_width(&self) -> f64 {
        self.width
    }
    pub fn get_height(&self) -> f64 {
        self.height
    }
}

// TODO: Implement constructor with setter and getter.
// 
// The radius is considered invalid if it is negative. 
// All methods should return the corresponding error when invalid values are provided.
impl Circle {
    pub fn new(radius: f64) -> Result<Self, Error> {
        match radius {
            n if n < 0.0 => Err(Error::InvalidRadius),
            _ => Ok(Self { radius: radius })
        }
    }
    pub fn set_radius(&mut self, radius: f64) -> Result<(), Error> {
        match radius {
            n if n < 0.0 => Err(Error::InvalidRadius),
            _ => Ok(self.radius = radius)
        }
    }
    pub fn get_radius(&self) -> f64 {
        self.radius
    }
}

// TODO: Implement the Shape trait for both Rectangle and Circle structs.
// 
// Hint: Use std::f64::consts::PI to calculate the area and circumference of the circle.
impl Shape for Rectangle{
    fn area(&self) -> f64 {
        self.height * self.width
    }
    fn perimeter(&self) -> f64{
        (self.height + self.width) *2.0
    }
}

impl Shape for Circle{
    fn area(&self) -> f64 {
        self.get_radius()*self.get_radius()*PI
    }
    fn perimeter(&self) -> f64{
        2.0 * PI * self.get_radius()
    }
}
