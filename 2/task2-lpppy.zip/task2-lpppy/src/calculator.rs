use std::i64;

///-------------------------------------------------------------------------------
///
/// This is your calculator implementation task
/// to practice enums, structs, and methods.
///
/// Complete the implementation of the Calculator struct and its methods.
///
/// The calculator should support basic arithmetic
/// operations (addition, subtraction, multiplication)
/// with overflow protection and maintain a history
/// of operations.
///
/// Tasks:
/// 1. Implement the OperationType enum methods
/// 2. Implement the Operation struct constructor
/// 3. Implement all Calculator methods
/// 
///-------------------------------------------------------------------------------

#[derive(Clone)]
pub enum OperationType {
    Addition,
    Subtraction,
    Multiplication,
}

impl OperationType {
    // TODO: Return the string representation of the operation sign
    // Addition -> "+", Subtraction -> "-", Multiplication -> "*"
    pub fn get_sign(&self) -> &str {
        match self {
            OperationType::Addition => "+",
            OperationType::Subtraction => "-",
            OperationType::Multiplication => "*",
        }
    }
    // TODO: Perform the operation on two i64 numbers with overflow protection
    // Return Some(result) on success, None on overflow
    //
    // Example: OperationType::Multiplication.perform(x, y)
    pub fn perform(&self, x: i64, y: i64) -> Option<i64> {
        if self.get_sign() == "+" {
            if y > 0 && x > i64::MAX - y {
                None
            } else if y < 0 && x < i64::MIN - y {
                None
            } else {
                Some(x + y)
            }
        } else if self.get_sign() == "-" {
            if x < 0 && y > 0 && x < i64::MIN + y {
                None
            } else if y < 0 && x > i64::MAX + y {
                None
            } else {
                Some(x - y)
            }
        } else {
            if x == 0 || y == 0 {
                Some(0)
            } else {
                x.checked_mul(y)
            }
        }
    }
}

#[derive(Clone)]
pub struct Operation {
    pub first_num: i64,
    pub second_num: i64,
    pub operation_type: OperationType,
}

impl Operation {
    // TODO: Create a new Operation with the given parameters
    pub fn new(first_num: i64, second_num: i64, operation_type: OperationType) -> Self {
        Self {
            first_num: first_num,
            second_num: second_num,
            operation_type: operation_type,
        }
    }
}

pub struct Calculator {
    pub history: Vec<Operation>,
}

impl Calculator {
    // TODO: Create a new Calculator with empty history
    pub fn new() -> Self {
        Self {
            history: Vec::new(),
        }
    }

    // TODO: Perform addition and store successful operations in history
    // Return Some(result) on success, None on overflow
    pub fn addition(&mut self, x: i64, y: i64) -> Option<i64> {
        self.history.push(Operation {
            first_num: x,
            second_num: y,
            operation_type: OperationType::Addition,
        });
        OperationType::perform(&OperationType::Addition, x, y)
    }

    // TODO: Perform subtraction and store successful operations in history
    // Return Some(result) on success, None on overflow
    pub fn subtraction(&mut self, x: i64, y: i64) -> Option<i64> {
        self.history.push(Operation {
            first_num: x,
            second_num: y,
            operation_type: OperationType::Subtraction,
        });
        OperationType::perform(&OperationType::Subtraction, x, y)
    }

    // TODO: Perform multiplication and store successful operations in history
    // Return Some(result) on success, None on overflow
    pub fn multiplication(&mut self, x: i64, y: i64) -> Option<i64> {
        self.history.push(Operation {
            first_num: x,
            second_num: y,
            operation_type: OperationType::Multiplication,
        });
        OperationType::perform(&OperationType::Multiplication, x, y)
    }

    // TODO: Generate a formatted string showing all operations in history
    // Format: "index: first_num operation_sign second_num = result\n"
    //
    // Example: "0: 5 + 3 = 8\n1: 10 - 2 = 8\n"
    pub fn show_history(&self) -> String {
        let mut result = String::new();
        for (i, e) in self.history.iter().enumerate() {
            match e.operation_type.perform(e.first_num, e.second_num) {
                Some(n) => result.push_str(&format!(
                    "{}: {} {} {} = {}\n",
                    i,
                    e.first_num,
                    e.operation_type.get_sign(),
                    e.second_num,
                    n
                )),
                _ => result.push_str(&format!(
                    "{}: {} {} {} = {}\n",
                    i,
                    e.first_num,
                    e.operation_type.get_sign(),
                    e.second_num,
                    0
                )),
            }
        }
        result
    }

    // TODO: Repeat an operation from history by index
    // Add the repeated operation to history and return the result
    // Return None if the index is invalid
    pub fn repeat(&mut self, operation_index: usize) -> Option<i64> {
        let l = self.history.len();
        if l == 0 || operation_index > l - 1 {
            return None;
        }
        let e = self.history.get(operation_index).unwrap();
        match e.operation_type {
            OperationType::Addition => self.addition(e.first_num, e.second_num),
            OperationType::Subtraction => self.subtraction(e.first_num, e.second_num),
            OperationType::Multiplication => self.multiplication(e.first_num, e.second_num),
        }
    }

    // TODO: Clear all operations from history
    pub fn clear_history(&mut self) {
        self.history.clear();
    }
}
